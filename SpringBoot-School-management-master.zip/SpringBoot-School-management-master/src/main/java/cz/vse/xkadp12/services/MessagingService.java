package cz.vse.xkadp12.services;

/**
 * Created by Admin on 15.4.2017.
 */
public class MessagingService {
}
