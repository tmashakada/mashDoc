package cz.vse.xkadp12.utils;

public enum ClassTimes {

    ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT;
}
